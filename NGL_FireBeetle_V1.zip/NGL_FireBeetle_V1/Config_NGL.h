
 

void Setup_NGL(void);

void Setup_PWM(void);
void Setup_ADC(void);
void Setup_I2C(void);
void Setup_SERIAL(void);